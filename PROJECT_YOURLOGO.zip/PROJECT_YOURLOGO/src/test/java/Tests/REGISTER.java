package Tests;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BaseClass.Utilities;
import Excel.ExcelData;
import Pages.Register1;
import Pages.Register2;
import Pages.Register3;
import Pages.Register4;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class REGISTER extends ExcelData{
	public static WebDriver dr;
	Utilities ut;
	Register1 reg1;
	Register2 reg2;
	Register3 reg3;
	Register4 reg4;
	
	@BeforeClass
	  public void beforeClass()
	{	
		getExcel("DATA_TO_ENTER");
	}

  @Test(priority=0)
	  public void page1()
  {
	  ut = new Utilities(dr);
	  dr = ut.bb("Chrome");
	  }
  
  @Test(priority=1)
  public void To_Signup()
  {
	  reg1=new Register1(dr);
	  reg1.Enter();
  }
	
  @Test(dataProvider = "dp")
  public void To_Create(String gmail) 
  {
	  reg2=new Register2(dr);
	  String mail = reg2.ToRegister(gmail);
	  System.out.println(mail);
  }
   @DataProvider(name="dp")
  public String[][] provider() 
   {
    String[][] data = {
    		{"shivaay@gmail.com","omkara@gmail.com","rudra@gmail.com"}
          };
    return data;
  }
   @Test(dataProvider = "Create_Account")
   public void To_FillData(String fname, String lname, String pwd, String ph, String a1, String ci, String zip, String a2)
   {
   	reg3=new Register3(dr);
	   String data_to_fill = reg3.Registration(fname, lname, pwd, ph, a1, ci, zip, a2);
	   //System.out.println(data_to_fill);
	}
   @DataProvider(name="Create_Account")
   public ExcelData provider1()
   {
	   return null;
   }
   
   @Test(dataProvider = "verify")
   public void To_verify(String profile_name) 
   {
	   reg4=new Register4(dr);
 	  String mail = reg4.Profile(profile_name);
 	  System.out.println(mail);
// 	  SoftAssert sa = new SoftAssert();
// 	  sa.assertEquals(true, false);
// 	  sa.assertAll();
   }
    @DataProvider(name="dp")
   public String[][] provider2() 
    {
     String[][] profile_name = {
     		{"shivaay","omkara","rudra"}
           };
     return profile_name;
    }

}
