package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BaseClass.Utilities;

public class Register3 {
	WebDriver dr;
	Utilities ut;
	public Register3(WebDriver dr)
	{
		this.dr = dr;
		ut = new Utilities(dr);
	}
	By gender = By.xpath("//div[@class='radio']//child::input[@value='1']");
	By firstname = By.xpath("//input[@id='customer_firstname']");
	By lastname = By.xpath("//input[@id='customer_lastname']");
	//By email = By.xpath("//input[@id='email']");
	By password = By.xpath("//input[@id='passwd']");
	//By first_name = By.xpath("//input[@id='firstname']");
	//By last_name = By.xpath("//input[@id='lastname']");
	By address = By.xpath("//input[@id='address1']");
	By city = By.xpath("//input[@id='city']");
	By state = By.xpath("//*[@id=\"id_state\"]/option[16]");
	By zip_code = By.xpath("//input[@id='postcode']");
	By country = By.xpath("//*[@id=\"id_country\"]//option[contains(text(),'United States')]");
	By phone = By.xpath("//input[@id='phone_mobile']");
	By alias_Address = By.xpath("//input[@value='My address']");
	By submit = By.xpath("//button[@id='submitAccount']");
	
	public void Gender()
		{
		WebElement data = ut.Explicit_wait(gender, 20);
		data.click();
		}
		
	public void Firstname(String r)
		{
		WebElement data = ut.Explicit_wait(firstname, 20);
		data.sendKeys(r);
		}
	
	public void Lastname(String r)
		{
		WebElement data = ut.Explicit_wait(lastname, 20);
		data.sendKeys(r);
		}
	
	/*
	 * public void Email(String r) { WebElement data = ut.Explicit_wait(email, 20);
	 * data.sendKeys(r); }
	 */
	
	public void Password (String r)
	{
		WebElement data = ut.Explicit_wait(password, 20);
		data.sendKeys(r);
	}
	
	/*
	 * public void First_Name(String r) { WebElement data =
	 * ut.Explicit_wait(first_name, 20); data.sendKeys(r); }
	 * 
	 * public void Last_Name(String r) { WebElement data =
	 * ut.Explicit_wait(last_name, 20); data.sendKeys(r); }
	 */
	
	public void Address(String r)
	{
		WebElement data = ut.Explicit_wait(address, 20);
		data.sendKeys(r);
	}
	
	public void City(String r)
	{
		WebElement data = ut.Explicit_wait(city, 20);
		data.sendKeys(r);
	}
	
	public void State()
	{
		WebElement data = ut.Explicit_wait(state, 20);
		data.click();
	}
	
	public void zip(String r)
	{
		WebElement data = ut.Explicit_wait(zip_code, 20);
		data.sendKeys(r);
	}
	
	public void country()
	{
		WebElement data = ut.Explicit_wait(country,20);
		data.click();
	}
	
	public void Phone(String r)
	{
		WebElement data = ut.Explicit_wait(phone,20);
		data.sendKeys(r);
	}
	
	public void AddressPrime(String r)
	{
		WebElement data = ut.Explicit_wait(alias_Address, 20);
		data.sendKeys(r);
	}
	
	public void Submit()
	{
		WebElement data = ut.Explicit_wait(submit, 20);
		data.click();
	}
	
	public String Registration(String fname, String lname, String pwd, String ph, String a1, String ci, String zip, String a2)
	{
		this.Gender();
		this.Firstname(fname);
		this.Lastname(lname);
		//this.Email(em);
		this.Password(pwd);
		//this.First_Name(fname);
	//	this.Last_Name(lname);
		this.Address(a1);
		this.City(ci);
		this.State();
		this.zip(zip);
		this.country();
		this.Phone(ph);
		this.AddressPrime(a2);
		this.Submit();
		return fname;
	}
}
	



