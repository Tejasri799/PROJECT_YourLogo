package Excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {
	public static String[][] data;

	public static String filename = "G:\\selenium_project\\MAVEN_PROJECT\\src\\test\\resources\\Testdata\\Reg&LogData.xlsx";
	   public static void getExcel(String Sheet){
	  data= new String[3][8];
	    File f= new File(filename);
	    for(int Row=1;Row<=3;Row++){
	  try {
	FileInputStream fis= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sheet=wb.getSheet(Sheet);
	XSSFRow row=sheet.getRow(Row);
	for(int column=0;column<=7;column++){
	XSSFCell cell=row.getCell(column);
	data[Row-1][column]=cell.getStringCellValue();
	}
	   } catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	  catch (IOException e)
	  		{
		  		// TODO Auto-generated catch block
		  		e.printStackTrace();
			}
	    }
   }
}
	